#ifndef TRACE_FILE_IS_DEF
#define TRACE_FILE_IS_DEF

#include "trace_data.h"

void trace_file_load  (char *file);

#endif