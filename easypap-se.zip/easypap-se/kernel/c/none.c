
#include "easypap.h"


// The kernel returns 0, or the iteration step at which computation has
// completed (e.g. stabilized).

///////////////////////////// Simple sequential version (seq)
unsigned none_compute_seq (unsigned nb_iter)
{
  // Do nothing
  return 1;
}
