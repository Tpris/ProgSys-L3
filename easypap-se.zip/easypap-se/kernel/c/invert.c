
#include "easypap.h"

#include <omp.h>

#define INV_MASK  ((unsigned)0xFFFFFF00)

static inline unsigned compute_color (int i, int j)
{
  return INV_MASK ^ cur_img (i, j);
}

///////////////////////////// Simple sequential version (seq)
// Suggested cmdline(s):
// ./run -l images/shibuya.png -k invert -v seq -i 100 -n
//
unsigned invert_compute_seq (unsigned nb_iter)
{
  for (unsigned it = 1; it <= nb_iter; it++) {

    for (int i = 0; i < DIM; i++)
      for (int j = 0; j < DIM; j++)
        cur_img (i, j) = compute_color (i, j);
  }

  return 0;
}

// Tile inner computation
static void do_tile_reg (int x, int y, int width, int height)
{
  for (int i = y; i < y + height; i++)
    for (int j = x; j < x + width; j++)
      cur_img (i, j) = compute_color (i, j);
}

static void do_tile (int x, int y, int width, int height, int who)
{
  monitoring_start_tile (who);

  do_tile_reg (x, y, width, height);

  monitoring_end_tile (x, y, width, height, who);
}

///////////////////////////// Tiled sequential version (tiled)
// Suggested cmdline(s):
// ./run -l images/shibuya.png -k invert -v tiled -ts 32 -i 100 -n
//
unsigned invert_compute_tiled (unsigned nb_iter)
{
  for (unsigned it = 1; it <= nb_iter; it++) {

    for (int y = 0; y < DIM; y += TILE_H)
      for (int x = 0; x < DIM; x += TILE_W)
        do_tile (x, y, TILE_W, TILE_H, 0 /* CPU id */);

  }

  return 0;
}

static int nbIter;
static void * thread_block(void*p){
  int nbThreads = easypap_requested_number_of_threads();
  int nbLignes = DIM/nbThreads;
  int id = (int)(intptr_t)p;
  int debut = id*nbLignes;
  int hauteur = (id==nbThreads-1)? (nbLignes+DIM%nbThreads) : nbLignes;
  //printf("%d : %d -> %d\n",id,debut,hauteur);
  // if(id%2==0)
  //   return NULL;
  for(int i = 0; i<nbIter; i++)
    do_tile(0,debut,DIM,hauteur,id);
  return NULL;
}

int invert_compute_thread(int nb_iter){
  nbIter=nb_iter;
  int nbThreads = easypap_requested_number_of_threads();
  pthread_t tids[nbThreads];
  for (int i = 0; i <nbThreads ; i++){
    pthread_create(tids + i, NULL, thread_block, (void *)(intptr_t)i);
  }
  for(int i = 0; i <nbThreads ; i++)
    pthread_join(tids[i],NULL);
  return 0;
}

/**
 * + il y a d'iterations mieux ca marche parce qu'il y a beaucoup de trav en 1 fois : granularité -> - de pb alloc/déalloc trav
 * 
 **/
